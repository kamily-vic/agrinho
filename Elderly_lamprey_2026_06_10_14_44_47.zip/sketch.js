function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(220);
}
let imgHero, img1, img2, img3;

function preload() {
  // Carrega imagens
  imgHero = loadImage('https://images.unsplash.com/photo-1500937386664-56d1dfef3854');
  img1 = loadImage('https://images.unsplash.com/photo-1501004318641-b39e6451bec6');
  img2 = loadImage('https://images.unsplash.com/photo-1500382017468-9049fed747ef');
  img3 = loadImage('https://images.unsplash.com/photo-1464226184884-fa280b87c399');
}

function setup() {
  createCanvas(1000, 800);
  textFont('Arial');
}

function draw() {
  background(244, 244, 244);

  // Header
  fill(46, 125, 50);
  rect(0, 0, width, 100);
  fill(255);
  textSize(32);
  textAlign(CENTER, CENTER);
  text('🌱 Agro Forte', width / 2, 35);
  textSize(16);
  text('O futuro do agronegócio começa aqui', width / 2, 70);

  // Hero banner
  image(imgHero, 0, 100, width, 300);
  fill(0, 0, 0, 150);
  rect(0, 100, width, 300);
  fill(255);
  textSize(28);
  text('Fortalecendo o Campo com Tecnologia', width / 2, 250);

  // Cards
  let cardY = 450;
  let cardX = 100;
  let cardWidth = 250;
  let cardHeight = 300;
  let gap = 50;

  drawCard(cardX, cardY, cardWidth, cardHeight, img1, 'Produção Sustentável', 'Técnicas modernas para aumentar a produtividade e preservar o meio ambiente.');
  drawCard(cardX + cardWidth + gap, cardY, cardWidth, cardHeight, img2, 'Tecnologia no Campo', 'Drones, sensores e inteligência artificial transformando a agricultura.');
  drawCard(cardX + 2 * (cardWidth + gap), cardY, cardWidth, cardHeight, img3, 'Colheita Inteligente', 'Máquinas modernas que aumentam a eficiência e reduzem desperdícios.');

  // Footer
  fill(27, 94, 32);
  rect(0, height - 60, width, 60);
  fill(255);
  textSize(16);
  text('© 2026 Agro Forte - Todos os direitos reservados.', width / 2, height - 30);
}

// Função para desenhar um card
function drawCard(x, y, w, h, img, title, description) {
  fill(255);
  stroke(0, 0, 0, 50);
  rect(x, y, w, h, 10);

  image(img, x, y, w, h / 2);

  fill(46, 125, 50);
  textSize(18);
  textAlign(LEFT, TOP);
  text(title, x + 10, y + h / 2 + 10, w - 20);

  fill(0);
  textSize(14);
  text(description, x + 10, y + h / 2 + 40, w - 20);
}